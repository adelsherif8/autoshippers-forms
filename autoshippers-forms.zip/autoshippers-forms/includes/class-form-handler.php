<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AS_Form_Handler {

    public function __construct() {
        add_action( 'wp_ajax_as_submit',           [ $this, 'handle_submit' ] );
        add_action( 'wp_ajax_nopriv_as_submit',    [ $this, 'handle_submit' ] );
        add_action( 'wp_ajax_as_test_connection',  [ $this, 'handle_test_connection' ] );
        add_action( 'wp_ajax_as_fetch_fields',     [ $this, 'handle_fetch_fields' ] );
        /* Always-fresh nonce — bypass page caching */
        add_action( 'wp_ajax_as_get_nonce',        [ $this, 'handle_get_nonce' ] );
        add_action( 'wp_ajax_nopriv_as_get_nonce', [ $this, 'handle_get_nonce' ] );
        /* Auto-create UTM custom fields in GHL inside a chosen folder */
        add_action( 'wp_ajax_as_create_utm_fields', [ $this, 'handle_create_utm_fields' ] );
        /* Funnel analytics events (view / step / submit) */
        add_action( 'wp_ajax_as_track',             [ $this, 'handle_track' ] );
        add_action( 'wp_ajax_nopriv_as_track',      [ $this, 'handle_track' ] );
    }

    /* ── Analytics: record a view / start / step / complete milestone ── */
    public function handle_track(): void {
        nocache_headers();
        $event_type = sanitize_key( $_POST['event_type'] ?? '' );
        $step_key   = sanitize_text_field( $_POST['step_key']   ?? '' );
        $session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
        $page_url   = esc_url_raw( $_POST['page_url'] ?? '' );
        $allowed    = [ 'view', 'start', 'step', 'complete' ];
        if ( ! in_array( $event_type, $allowed, true ) || $session_id === '' ) {
            wp_send_json_error();
            return;
        }
        AS_Events::insert( $event_type, $step_key, $session_id, $page_url );
        wp_send_json_success();
    }

    /* ── Auto-create the UTM custom fields in GHL ──
       Resolves the folder automatically (existing "UTM forms" folder or
       the folder containing existing utm fields, otherwise creates one),
       then creates each missing field inside it. */
    public function handle_create_utm_fields(): void {
        if ( ! check_ajax_referer( 'as_admin', 'nonce', false ) || ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized.' ], 403 );
        }

        $api_key     = get_option( 'as_ghl_api_key', '' );
        $location_id = get_option( 'as_ghl_location_id', '' );

        if ( $api_key === '' || $location_id === '' ) {
            wp_send_json_error( [ 'message' => 'Save API Key and Location ID first.' ] );
        }

        /* Resolve folder ID:
           1. From POST (user pasted it in the input)
           2. Cached value
           3. Auto-discovery (best-effort)
           4. Auto-create (best-effort) */
        $folder_notes = [];
        $folder_id    = sanitize_text_field( $_POST['folder_id'] ?? '' );

        if ( $folder_id === '' ) $folder_id = trim( (string) get_option( 'as_utm_folder_id', '' ) );
        if ( $folder_id === '' ) $folder_id = $this->discover_utm_folder( $api_key, $location_id, $folder_notes );
        if ( $folder_id === '' ) $folder_id = $this->create_utm_folder( $api_key, $location_id, $folder_notes );

        if ( $folder_id === '' ) {
            wp_send_json_error( [ 'message' => 'Could not resolve a UTM folder. Paste the folder UUID in the input above and retry. Details: ' . implode( ' | ', $folder_notes ) ] );
        }
        update_option( 'as_utm_folder_id', $folder_id );

        /* Plugin slot → [ name shown in GHL, fieldKey ]
           These are the 6 canonical fields the scad_tracking_params script uses. */
        $defs = [
            'as_cf_utm_campaign' => [ 'UTMCampaign_Custom', 'utmcampaign_custom' ],
            'as_cf_utm_medium'   => [ 'UTMmedium_custom',   'utmmedium_custom'   ],
            'as_cf_utm_content'  => [ 'UTMContent_custom',  'utmcontent_custom'  ],
            'as_cf_utm_keyword'  => [ 'utmkeyword_custom',  'utmkeyword_custom'  ],
            'as_cf_utm_term'     => [ 'utmterm_custom',     'utmterm_custom'     ],
            'as_cf_gclid'        => [ 'gclid_custom',       'gclid_custom'       ],
            'as_cf_latest_form_date' => [ 'Latest Form Date', 'latest_form_date' ],
        ];

        $created = [];
        $skipped = [];
        $failed  = [];
        $position = 0;

        foreach ( $defs as $option_key => [ $name, $field_key ] ) {
            $existing = trim( (string) get_option( $option_key, '' ) );
            if ( $existing !== '' ) {
                $skipped[] = $name;
                continue;
            }

            $resp = wp_remote_post(
                'https://services.leadconnectorhq.com/locations/' . rawurlencode( $location_id ) . '/customFields',
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $api_key,
                        'Content-Type'  => 'application/json',
                        'Version'       => '2021-07-28',
                    ],
                    'body'    => wp_json_encode( [
                        'name'        => $name,
                        'dataType'    => 'TEXT',
                        'fieldKey'    => $field_key,
                        'parentId'    => $folder_id,
                        'placeholder' => '',
                        'model'       => 'contact',
                        'position'    => $position++,
                        'showInForms' => true,
                    ] ),
                    'timeout' => 20,
                ]
            );

            if ( is_wp_error( $resp ) ) {
                $failed[] = "$name: " . $resp->get_error_message();
                continue;
            }
            $code = wp_remote_retrieve_response_code( $resp );
            $body = json_decode( wp_remote_retrieve_body( $resp ), true );

            if ( in_array( $code, [ 200, 201 ], true ) ) {
                $id = $body['customField']['id'] ?? $body['id'] ?? '';
                if ( $id ) {
                    update_option( $option_key, sanitize_text_field( $id ) );
                    $created[] = [ 'name' => $name, 'id' => $id, 'slot' => $option_key ];
                } else {
                    $failed[] = "$name: created but no id returned";
                }
            } else {
                $msg = $body['message'] ?? $body['msg'] ?? "HTTP $code";
                $failed[] = "$name: $msg";
            }
        }

        wp_send_json_success( [
            'created'   => $created,
            'skipped'   => $skipped,
            'failed'    => $failed,
            'folder_id' => $folder_id,
            'folder'    => $folder_notes,
        ] );
    }

    /* Discover the UTM folder. Tries:
       1. A folder document explicitly named "UTM forms" / containing "utm"
       2. The parentId of any existing field whose name/key contains "utm" */
    private function discover_utm_folder( string $api_key, string $location_id, array &$notes ): string {
        /* Fetch WITHOUT model filter so folder documents are included */
        $resp = wp_remote_get(
            'https://services.leadconnectorhq.com/locations/' . rawurlencode( $location_id ) . '/customFields',
            [
                'headers' => [ 'Authorization' => 'Bearer ' . $api_key, 'Version' => '2021-07-28' ],
                'timeout' => 20,
            ]
        );
        if ( is_wp_error( $resp ) ) { $notes[] = 'discover: ' . $resp->get_error_message(); return ''; }
        $code = wp_remote_retrieve_response_code( $resp );
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( $code !== 200 ) { $notes[] = 'discover HTTP ' . $code; return ''; }

        $items = $body['customFields'] ?? $body['folders'] ?? [];

        /* Pass 1: explicit folder document with UTM in the name */
        foreach ( $items as $f ) {
            $doc = strtolower( $f['documentType'] ?? '' );
            if ( $doc !== 'folder' ) continue;
            $name = strtolower( $f['name'] ?? '' );
            if ( strpos( $name, 'utm' ) !== false ) {
                $id = $f['id'] ?? $f['_id'] ?? '';
                if ( $id ) {
                    $notes[] = 'discover: found existing folder "' . ( $f['name'] ?? '' ) . '"';
                    return $id;
                }
            }
        }

        /* Pass 2: fall back to a parentId of any field with "utm" in name/key */
        foreach ( $items as $f ) {
            $name = strtolower( $f['name']     ?? '' );
            $key  = strtolower( $f['fieldKey'] ?? '' );
            if ( ( strpos( $name, 'utm' ) !== false || strpos( $key, 'utm' ) !== false )
                 && ! empty( $f['parentId'] ) ) {
                $notes[] = 'discover: reused folder from field "' . ( $f['name'] ?? '' ) . '"';
                return $f['parentId'];
            }
        }

        /* Pass 3: a dedicated folders endpoint, if GHL exposes it */
        $resp2 = wp_remote_get(
            'https://services.leadconnectorhq.com/locations/' . rawurlencode( $location_id ) . '/customFields/folders',
            [
                'headers' => [ 'Authorization' => 'Bearer ' . $api_key, 'Version' => '2021-07-28' ],
                'timeout' => 20,
            ]
        );
        if ( ! is_wp_error( $resp2 ) && wp_remote_retrieve_response_code( $resp2 ) === 200 ) {
            $b2 = json_decode( wp_remote_retrieve_body( $resp2 ), true );
            foreach ( ( $b2['folders'] ?? $b2['customFieldFolders'] ?? [] ) as $f ) {
                $name = strtolower( $f['name'] ?? '' );
                if ( strpos( $name, 'utm' ) !== false ) {
                    $id = $f['id'] ?? $f['_id'] ?? '';
                    if ( $id ) {
                        $notes[] = 'discover: found folder via folders endpoint';
                        return $id;
                    }
                }
            }
        }

        $notes[] = 'discover: no UTM folder found';
        return '';
    }

    /* Create a new "UTM forms" folder. Tries multiple endpoint variants
       since GHL's API version differs between accounts. */
    private function create_utm_folder( string $api_key, string $location_id, array &$notes ): string {
        $headers = [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
            'Version'       => '2021-07-28',
        ];
        $base = 'https://services.leadconnectorhq.com/locations/' . rawurlencode( $location_id );

        $attempts = [
            [ 'url' => $base . '/customFields/folder',  'body' => [ 'name' => 'UTM forms', 'model' => 'contact' ] ],
            [ 'url' => $base . '/customFields/folders', 'body' => [ 'name' => 'UTM forms', 'model' => 'contact' ] ],
            [ 'url' => $base . '/customFields',         'body' => [ 'name' => 'UTM forms', 'model' => 'contact', 'documentType' => 'folder' ] ],
        ];

        foreach ( $attempts as $a ) {
            $resp = wp_remote_post( $a['url'], [
                'headers' => $headers,
                'body'    => wp_json_encode( $a['body'] ),
                'timeout' => 20,
            ] );
            if ( is_wp_error( $resp ) ) {
                $notes[] = 'create ' . $a['url'] . ': ' . $resp->get_error_message();
                continue;
            }
            $code = wp_remote_retrieve_response_code( $resp );
            $body = json_decode( wp_remote_retrieve_body( $resp ), true );
            if ( in_array( $code, [ 200, 201 ], true ) ) {
                $id = $body['folder']['id'] ?? $body['customField']['id'] ?? $body['id'] ?? $body['customFieldFolder']['id'] ?? '';
                if ( $id ) {
                    $notes[] = 'created new folder via ' . basename( $a['url'] );
                    return $id;
                }
                $notes[] = $a['url'] . ': 200 but no id returned';
            } else {
                $msg = $body['message'] ?? $body['msg'] ?? "HTTP $code";
                $notes[] = basename( $a['url'] ) . ': ' . $msg;
            }
        }
        return '';
    }

    public function handle_get_nonce(): void {
        nocache_headers();
        wp_send_json_success( [ 'nonce' => wp_create_nonce( 'as_submit' ) ] );
    }

    /* ── Form submission ── */
    public function handle_submit(): void {
        if ( ! check_ajax_referer( 'as_submit', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed.' ], 403 );
        }

        $p = $this->sanitize_post();

        /* Never hand the CRM a lead that is missing the contact essentials. The
           browser blocks this too, but a bot or a stale cached script can still
           POST straight here — that is how phone-less leads got through. */
        foreach ( [ 'first_name' => 'first name', 'email' => 'email', 'phone' => 'phone number' ] as $key => $label ) {
            if ( $p[ $key ] === '' ) {
                wp_send_json_error( [ 'message' => "Please enter your {$label}." ], 400 );
            }
        }

        $p['phone'] = $this->normalize_phone( $p['phone'] );

        /* Resolve "Other" city values */
        $from = $p['from_city'] === 'Other' && $p['from_other'] !== ''
            ? $p['from_other']
            : $p['from_city'];

        $to = $p['to_city'] === 'Other' && $p['to_other'] !== ''
            ? $p['to_other']
            : $p['to_city'];

        /* Build custom fields. UTMs come from the canonical scad_tracking_params
           keys (utmcampaign_custom, utmmedium_custom, …). We still write to the
           existing utm_medium / utm_campaign / utm_content / utm_keyword admin
           slots since the user already has them mapped. */
        $custom_fields = AS_GHL_API::build_custom_fields_v2( [
            'as_cf_move_type'         => $p['move_type'],
            'as_cf_pickup_date'       => $p['pickup_date'],
            'as_cf_from_city'         => $from,
            'as_cf_to_city'           => $to,
            'as_cf_vehicle_type'      => $p['vehicle_type'],
            'as_cf_vehicle_status'    => $p['vehicle_status'],
            'as_cf_utm_campaign' => $p['utmcampaign_custom'],
            'as_cf_utm_medium'   => $p['utmmedium_custom'],
            'as_cf_utm_content'  => $p['utmcontent_custom'],
            'as_cf_utm_keyword'  => $p['utmkeyword_custom'],
            'as_cf_utm_term'     => $p['utmterm_custom'],
            'as_cf_gclid'        => $p['gclid_custom'],
            /* Stamped on every submission so the contact always carries the
               date of their most recent form fill. */
            'as_cf_latest_form_date' => current_time( 'Y-m-d' ),
        ] );

        $payload = [
            'firstName' => $p['first_name'],
            'lastName'  => $p['last_name'],
            'email'     => $p['email'],
            'phone'     => $p['phone'],
            'tags'      => [ 'AutoShippers - Vehicle Quote' ],
        ];

        if ( ! empty( $custom_fields ) ) {
            $payload['customFields'] = $custom_fields;
        }

        /* Save entry locally before calling GHL so we never lose a lead */
        $entry_data = [
            'move_type'      => $p['move_type'],
            'pickup_date'    => $p['pickup_date'],
            'from_city'      => $from,
            'to_city'        => $to,
            'vehicle_type'   => $p['vehicle_type'],
            'vehicle_status' => $p['vehicle_status'],
        ];
        foreach ( [ 'utmcampaign_custom','utmmedium_custom','utmcontent_custom','utmkeyword_custom','utmterm_custom','gclid_custom' ] as $k ) {
            if ( ! empty( $p[ $k ] ) ) $entry_data[ $k ] = $p[ $k ];
        }

        $entry_id = AS_Entries::insert( [
            'first_name' => $p['first_name'],
            'last_name'  => $p['last_name'],
            'email'      => $p['email'],
            'phone'      => $p['phone'],
            'tag'        => $payload['tags'][0] ?? '',
            'data'       => $entry_data,
            'ip'         => $this->get_ip(),
        ] );

        $api    = new AS_GHL_API();
        $result = $api->upsert_contact( $payload );

        AS_Entries::update_ghl_status(
            $entry_id,
            $result['success'] ? 'sent' : 'failed',
            $result['message']  ?? '',
            $result['request']  ?? '',
            $result['response'] ?? '',
            intval( $result['http'] ?? 0 )
        );

        if ( $result['success'] ) {
            wp_send_json_success( [ 'message' => 'Quote request sent.' ] );
        } else {
            wp_send_json_error( [ 'message' => $result['message'] ?? 'Submission failed.' ] );
        }
    }

    /* ── Test connection ── */
    public function handle_test_connection(): void {
        if ( ! check_ajax_referer( 'as_admin', 'nonce', false ) || ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized.' ], 403 );
        }

        $api_key     = sanitize_text_field( $_POST['api_key']     ?? '' );
        $location_id = sanitize_text_field( $_POST['location_id'] ?? '' );

        $api    = new AS_GHL_API( $api_key, $location_id );
        $result = $api->test_connection();

        if ( $result['success'] ) {
            wp_send_json_success( [ 'name' => $result['name'] ] );
        } else {
            wp_send_json_error( [ 'message' => $result['message'] ] );
        }
    }

    /* ── Fetch GHL custom fields ── */
    public function handle_fetch_fields(): void {
        if ( ! check_ajax_referer( 'as_admin', 'nonce', false ) || ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized.' ], 403 );
        }

        $api_key     = sanitize_text_field( $_POST['api_key']     ?? '' );
        $location_id = sanitize_text_field( $_POST['location_id'] ?? '' );

        $response = wp_remote_get(
            'https://services.leadconnectorhq.com/locations/' . rawurlencode( $location_id ) . '/customFields',
            [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'Version'       => '2021-07-28',
                ],
                'timeout' => 15,
            ]
        );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => $response->get_error_message() ] );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            wp_send_json_error( [ 'message' => $body['message'] ?? "HTTP $code" ] );
        }

        $fields = array_map( fn( $f ) => [
            'name' => $f['name']     ?? '',
            'key'  => $f['fieldKey'] ?? '',
            'id'   => $f['id']       ?? '',
        ], $body['customFields'] ?? [] );

        wp_send_json_success( [ 'fields' => $fields ] );
    }

    /* ── Helpers ── */
    private function sanitize_post(): array {
        $keys = [
            'move_type', 'pickup_date', 'from_city', 'from_other',
            'to_city', 'to_other', 'vehicle_type', 'vehicle_status',
            'first_name', 'last_name', 'email', 'phone',
            'utmcampaign_custom', 'utmmedium_custom', 'utmcontent_custom',
            'utmkeyword_custom',  'utmterm_custom',    'gclid_custom',
        ];
        $out = [];
        foreach ( $keys as $k ) {
            $out[ $k ] = sanitize_text_field( $_POST[ $k ] ?? '' );
        }
        $out['email'] = sanitize_email( $_POST['email'] ?? '' );
        return $out;
    }

    /* Mirror of the browser's E.164 normalisation, in case the value arrives raw:
       a bare 10-digit number is North American, so it gets a +1. */
    private function normalize_phone( string $phone ): string {
        $phone  = trim( $phone );
        $digits = preg_replace( '/\D/', '', $phone );
        if ( $digits === '' ) return '';
        if ( str_starts_with( $phone, '+' ) )                 return '+' . $digits;
        if ( strlen( $digits ) === 10 )                       return '+1' . $digits;
        if ( strlen( $digits ) === 11 && $digits[0] === '1' ) return '+' . $digits;
        return $phone;
    }

    private function get_ip(): string {
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                return sanitize_text_field( explode( ',', $_SERVER[ $key ] )[0] );
            }
        }
        return '0.0.0.0';
    }
}

new AS_Form_Handler();
